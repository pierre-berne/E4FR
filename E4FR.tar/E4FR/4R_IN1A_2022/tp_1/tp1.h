#ifndef _TP1_H
#define _TP1_H

void print_message(char*);

#endif
