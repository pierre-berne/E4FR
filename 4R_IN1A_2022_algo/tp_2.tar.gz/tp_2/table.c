#include <stdio.h>
#include <stdlib.h>
#include "table.h"

int rec_search(Table*, int, int, int);

Table* new_table(int size){

	Table* table = (Table*)malloc(sizeof(Table));
	if(table==NULL) return NULL;

	table->data = (int*)malloc(sizeof(int)*size);
	if(table->data == NULL){
		free(table);
		return NULL;
	}
	table->size=size; table->n=0;
	return table;
}


void free_table(Table* table){
	free(table->data);
	free(table);
}

void print_table(Table* table){
	int i = 0;
	for(;i<table->n;i++){
		printf("[%d]", table->data[i]);
	}
	printf("\n");
}

int is_sorted(Table* table){
	int i = 0;
	while(i<table->n-1){
		if(table->data[i+1] < table->data[i])	return 0; 
		i++;
	}
	return 1;
}
	
int dicho_search(Table * t, int x){
	return rec_search(t, x, 0, t->n-1);
}

int rec_search(Table *t, int x, int min, int max){	

	int mid = min + (max-min)/2;
	if(x == t->data[mid]) return 	mid;

	if(x > t->data[mid]){
		if(min < mid) return rec_search(t,x,mid+1,max);
		return -1;
	}
	
	if(mid < max) return rec_search(t,x,min,mid-1);
	return -1;
}


int insert(Table *t, int e){

	int newsize, i = 0 , j=t->n ;
	int * newtab;

	if(t->n == t->size){
		newsize = t->size*RATIO/100 + t->size;
		newtab = (int*)realloc(t->data, sizeof(int)*newsize);
	

		if(newtab == NULL) return -1;

		t->data=newtab;
		t->size = newsize;
	}

	for(i=0;i<t->n;i++){ if(t->data[i] > e) break; }
	for(j=t->n;j>i;j--){ t->data[j] = t->data[j-1]; }

	t->data[i] = e;
	t->n = t->n+1;

	return i;	
}
