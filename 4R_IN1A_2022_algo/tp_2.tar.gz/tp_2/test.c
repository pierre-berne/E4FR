#include <stdio.h>
#include <stdlib.h>
#include "table.h"

int main(){
        Table* table = new_table(5); 
	Table* table_2 = new_table(6);       
/**
	table->data[0]=5;
        table->data[1]=8;
        table->data[2]=156;
        table->data[3]=13;
        table->data[4]=9;
        table->n=5;
	print_table(table);
        printf("Tableau trie ? (oui=1, non=0): %d\n", is_sorted(table));
**/
        table_2->data[0]=5;
        table_2->data[1]=8;
        table_2->data[2]=156;
        table_2->data[3]=1316;
        table_2->data[4]=965468;
	table_2->data[5]=1645646;
        table_2->n=6;

	print_table(table_2);

        printf("Tableau trie ? (oui=1, non=0): %d\n", is_sorted(table_2));

	printf("> position de la valeur 5 : %d\n\n", dicho_search(table_2, 5));
	printf("> position de la valeur 156 : %d\n\n", dicho_search(table_2, 156));
	printf("> position de la valeur 1316 : %d\n\n", dicho_search(table_2,1316));
	printf("> position de la valeur 23 : %d\n\n", dicho_search(table_2, 23));

	insert(table_2, 55);
	insert(table_2, 5556);
	insert(table_2, 35);


	print_table(table_2);

        printf("Tableau trie ? (oui=1, non=0): %d\n", is_sorted(table_2));

        free_table(table);
	free_table(table_2);
        return 0;
}

