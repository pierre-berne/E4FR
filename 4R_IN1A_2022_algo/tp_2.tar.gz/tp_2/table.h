#ifndef _TP1_H
#define _TP1_H
#define RATIO 50

typedef struct Table{

	int * data;	
	int size;
	int n;

} Table;

Table* new_table(int);
void free_table(Table*);
void print_table(Table*);
int is_sorted(Table*);
int dicho_search(Table*, int);
int insert(Table*, int);
int random_inserts(Table*, int);
void shuffle(Table*);

#endif
